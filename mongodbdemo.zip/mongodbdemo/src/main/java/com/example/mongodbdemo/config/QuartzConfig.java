package com.example.mongodbdemo.config;

import com.mongodb.MongoClientURI;
import org.quartz.spi.JobFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import java.io.IOException;
import java.util.Properties;

@Configuration
public class QuartzConfig {

    @Autowired
    ApplicationContext applicationContext;

    @Bean
    public JobFactory jobFactory() {
        AutowiringSpringBeanJobFactory jobFactory = new AutowiringSpringBeanJobFactory();
        jobFactory.setApplicationContext(applicationContext);
        return jobFactory;
    }


    @Bean
    public SchedulerFactoryBean schedulerFactoryBean() throws IOException {

        MongoClientURI uri = new MongoClientURI("mongodb://localhost:27017/test3");

        try {
            SchedulerFactoryBean quartzScheduler = new SchedulerFactoryBean();
            quartzScheduler.setOverwriteExistingJobs(true);
            quartzScheduler.setSchedulerName("Merlin-Quartz-Scheduler");
            quartzScheduler.setJobFactory(jobFactory());

            Properties quartzProperties = new Properties();
            quartzProperties.setProperty("org.quartz.scheduler.instanceName", "Quartz_Instance");
            quartzProperties.setProperty("org.quartz.scheduler.instanceId", "AUTO");
            quartzProperties.setProperty("org.quartz.threadPool.threadCount", "10");
            quartzProperties.setProperty("org.quartz.jobStore.mongoUri", "mongodb://localhost:27017/test3");
            quartzProperties.setProperty("org.quartz.jobStore.class", "com.novemberain.quartz.mongodb.MongoDBJobStore");
            quartzProperties.setProperty("org.quartz.jobStore.dbName", uri.getDatabase());
            quartzProperties.setProperty("org.quartz.jobStore.collectionPrefix", "quartz");
            quartzProperties.setProperty("org.quartz.jobStore.misfireThreshold", "3000");
            quartzProperties.setProperty("org.quartz.jobStore.isClustered", "true");

//            quartzProperties.setProperty("org.quartz.jobStore.checkInErrorHandler.class", "com.novemberain.quartz.mongodb.cluster.NoOpErrorHandler");
            quartzScheduler.setQuartzProperties(quartzProperties);

            return quartzScheduler;
        } catch (Exception e) {
//            logger.error("Quartz Scheduler can not be initialized, the error is ", e);
            return null;
        }
    }

    public Properties quartzProperties() throws IOException {
        PropertiesFactoryBean propertiesFactoryBean = new PropertiesFactoryBean();
        propertiesFactoryBean.setLocation(new ClassPathResource("/quartz.properties"));
        propertiesFactoryBean.afterPropertiesSet();
        return propertiesFactoryBean.getObject();
    }

}