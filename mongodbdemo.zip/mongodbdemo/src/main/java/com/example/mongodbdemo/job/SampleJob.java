package com.example.mongodbdemo.job;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SampleJob implements Job {
    private static final Logger log = LoggerFactory.getLogger(SampleJob.class);



    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {

//        /* Get counter id recorded by scheduler during scheduling */
        JobDataMap dataMap = context.getJobDetail().getJobDataMap();

        String counterId = dataMap.getString("counterId");

        log.info("Executing job for counter id {}", counterId);

    }

}